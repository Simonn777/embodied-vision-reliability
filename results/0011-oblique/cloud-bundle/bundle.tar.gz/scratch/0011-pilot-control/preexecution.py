import hashlib,json,subprocess,os,time,platform,sys
from pathlib import Path
from datetime import datetime,timezone
b=Path('/workspace/scratch/a349d03a0e0a');r=b/'research-0011-oblique';c=b/'scratch/0011-pilot-control'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for a in iter(lambda:f.read(1<<20),b''):h.update(a)
 return h.hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
def stat(p):
 s=p.lstat();return dict(bytes=s.st_size,dev=s.st_dev,inode=s.st_ino,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
head='a0b061660f78487f67fc4dedad6ad0c99aca4de7';src='a288f65bfb9d9e0d70dee72c0d83b020a0339458';oldhead='1951ae7bfd47f601c7187ee72ddd03ab905e7b56';fp='protocols/0011-oblique-development-freeze.json';pin='f45cfe56f99cdb8c4cb2ad6376a3c0813693666e2798941b9627d535c7a61e46'
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain') and not git('diff',head,oldhead)
assert sha(r/fp)==pin and git('rev-parse',oldhead+'^').decode().strip()==src
assert git('diff-tree','--no-commit-id','--name-only','-r',oldhead).decode().strip()==fp
f=json.loads((r/fp).read_text());assert f['source_commit']==src and len(f['files'])==24
for n,h in f['files'].items():
 raw=(r/n).read_bytes();assert not (r/n).is_symlink() and sha(r/n)==h
 for ref in [src+':'+n,head+':'+n,':'+n]:assert git('show',ref)==raw
assert not (b/'scratch/0011-oblique-v1').exists() and not (b/'scratch/0011-oblique-v1').is_symlink()
assert {0,1,2,3}<=set(os.sched_getaffinity(0));assert Path('/sys/fs/cgroup/memory.max').read_text().strip()==str(8*1024**3)
tracked={n:sha(r/n) for n in git('ls-files','-z').decode().split('\0') if n}
cache={}
for folder in ['bootstapir-cache','tapnextpp-cache','tapnextpp-recovery']:
 root=b/folder
 for p in root.iterdir():
  if p.is_file() and not p.is_symlink():
   d=stat(p)
   if p.stat().st_size<=1024**2:d['sha256']=sha(p)
   cache[str(p.relative_to(b))]=d
for p in (b/'tapnextpp-recovery/source/tapnet').rglob('*.py'):cache[str(p.relative_to(b))]=stat(p)|{'sha256':sha(p)}
for p in (b/'tapnextpp-recovery/weights').iterdir():
 if p.is_file():cache[str(p.relative_to(b))]=stat(p)
# Preserve known previous once-only operations without scanning unrelated roots.
markers={}
for folder in ['scratch/0010-headroom-control','scratch/0010-headroom-output','scratch/0010-headroom-supervision','scratch/0011-software-validation']:
 for p in (b/folder).iterdir():
  if p.is_file():markers[str(p.relative_to(b))]=dict(bytes=p.stat().st_size,sha256=sha(p))
for p in (b/'clip-0010-assets').glob('*started.json'):markers[str(p.relative_to(b))]=dict(bytes=p.stat().st_size,sha256=sha(p))
record=dict(status='PASS_PREEXECUTION_NO_SCIENCE_STARTED',utc=datetime.now(timezone.utc).isoformat(),head=head,source_commit=src,canonical_sha256=pin,required_inputs=f['files'],tracked=tracked,old_cache=cache,previous_controls_and_markers=markers,python=sys.executable,python_version=sys.version,platform=platform.platform(),available_affinity=sorted(os.sched_getaffinity(0)),memory={n:(Path('/sys/fs/cgroup')/n).read_text() for n in ['memory.max','memory.current','memory.events']},scope='Once-only prepare,g-036,g-002,derive,score. No install/download or old-result changes.')
(c/'preexecution.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(status=record['status'],head=head,frozen_files=24,tracked_files=len(tracked),cache_metadata_files=len(cache),prior_controls_markers=len(markers),scientific_output_absent=True)))
