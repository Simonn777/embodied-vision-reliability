"""Read-only source/cache and saved-receipt checks. No array decoding/model/metric invocation."""
from pathlib import Path
import json,hashlib,subprocess,os
b=Path('/workspace/scratch/a349d03a0e0a');r=b/'research-0011-oblique';c=b/'scratch/0011-pilot-control';o=b/'scratch/0011-oblique-v1'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for x in iter(lambda:f.read(1<<20),b''):h.update(x)
 return h.hexdigest()
def spec(p):return dict(bytes=p.stat().st_size,sha256=sha(p))
def stat(p):
 s=p.lstat();return dict(bytes=s.st_size,dev=s.st_dev,inode=s.st_ino,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
def load(p):return json.loads(p.read_text())
f=load(c/'preexecution.json');checks=0
def ck(ok,label):
 global checks
 checks+=1
 if not ok:raise ValueError(label)
ck(subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip()==f['head'],'main')
ck(not subprocess.check_output(['git','status','--porcelain'],cwd=r),'clean')
for n,h in f['tracked'].items():ck(sha(r/n)==h,'tracked '+n)
for n,d in f['old_cache'].items():
 p=b/n;ck(not p.is_symlink() and stat(p)=={k:v for k,v in d.items() if k!='sha256'},'old cache stat '+n)
 if 'sha256' in d:ck(sha(p)==d['sha256'],'cache hash '+n)
for n,d in f['previous_controls_and_markers'].items():ck(spec(b/n)==d,'previous '+n)
ck(sha(r/'protocols/0011-oblique-development-freeze.json')==f['canonical_sha256'],'canonical')
for n,h in f['required_inputs'].items():ck(sha(r/n)==h,'input '+n)
phases={}
for phase in ['prepare','g-036','g-002','derive','score']:
 p=o/'supervision'/phase;e=load(p/'execution.json');s=load(p/'source-binding.json')
 ck((c/(phase+'.tool-exit.txt')).read_text().strip()=='0','actual tool command '+phase)
 ck(e['supervisor_exit_code']==e['child_exit_code']==e['raw_wait_status']==0 and not e['timed_out'],'phase '+phase)
 ck(s==dict(freeze_sha256=f['canonical_sha256'],source_commit=f['source_commit'],execution_sha256=sha(p/'execution.json')),'source binding '+phase)
 for n,d in e['logs'].items():ck(spec(p/n)==d,'logs '+phase+'/'+n)
 phases[phase]={k:e[k] for k in ['supervisor_exit_code','child_exit_code','raw_wait_status','wall_seconds','max_rss_kib','user_cpu_seconds','system_cpu_seconds','wall_limit_seconds','memory_limit_bytes','cpu_affinity','threads']}
prep=load(o/'prepared/receipt.json');ck(prep['status']=='completed_preparation','prep')
for n,d in prep['files'].items():ck(spec(o/'prepared'/n)==d,'prepared file '+n)
groups={}
for group in ['g-036','g-002']:
 receipt=load(o/'predictions'/group/'receipt.json');ck(receipt['status']=='completed_predictions' and receipt['forwards_attempted']==receipt['completed_predictions']==64,'group '+group)
 groups[group]={k:receipt[k] for k in ['status','forwards_attempted','completed_predictions','point_ids','frame_ids','view_order']}
seal=load(o/'derived/seal.json');ck(seal['status']=='sealed' and seal['rows']==256 and seal['model_calls']==0 and seal['GT_opened'] is False,'derive seal')
for n,d in seal['files'].items():ck(spec(o/'derived'/n)==d,'derived file '+n)
ck(spec(o/'prepared/receipt.json')==seal['inputs']['preparation_receipt'],'prep seal')
for group in ['g-036','g-002']:
 bound=seal['inputs'][group];ck(spec(o/'predictions'/group/'receipt.json')==bound['receipt'],'group receipt seal')
 for n,d in bound['frames'].items():ck(spec(o/'predictions'/group/n)==d,'raw output sealed '+group+'/'+n)
result=load(o/'evaluation/results.json');erec=load(o/'evaluation/receipt.json');ck(result['status']==erec['status']=='completed_evaluation' and result['model_calls']==0,'score');ck(result['seal_sha256']==sha(o/'derived/seal.json'),'score seal')
# Report saved summary; do not rerun production scorer or reconstruct errors.
procs=[]
for p in Path('/proc').glob('[0-9]*/cmdline'):
 try:a=p.read_bytes().split(bytes([0]));exe=Path(a[0].decode(errors='replace')).name
 except (OSError,IndexError):continue
 if not exe.startswith(('python','timeout')):continue
 if any(Path(arg.decode(errors='replace')).name in ['supervise_oblique.py','prepare_oblique_development.py','run_oblique_predictions.py','evaluate_oblique_saved.py','run_state_intervention.py','run_antithetic_training.py','run_antithetic_gradient_screen.py','run_conditional_residual_stage0.py'] for arg in a[1:3]):procs.append({'pid':int(p.parent.name),'script':Path(a[1].decode(errors='replace')).name})
ck(not procs,'no residual scientific process')
files={str(p.relative_to(o)):spec(p) for p in o.rglob('*') if p.is_file()}
post=dict(status='PASS_READONLY_POSTCHECK',checks=checks,head=f['head'],source_commit=f['source_commit'],freeze_sha256=f['canonical_sha256'],old_tracked_files_preserved=len(f['tracked']),old_cache_metadata_files_preserved=len(f['old_cache']),prior_control_marker_files_preserved=len(f['previous_controls_and_markers']),old_cache_boundary='Large cache files checked by unchanged full stat metadata; recorded small files also rehashed. Existing scientific raw files only hashed; no NPZ decoding in this postcheck.',phases=phases,groups=groups,derived_rows=seal['rows'],methods=load(o/'derived/predictions.json')['methods'],result_summary=result,new_output_inventory=files,related_processes=procs,new_asset_bytes=0,publication='None; private raw RGB/GT/model assets not exported.',readonly_summary_exceptions=load(c/'readonly-summary-errors.json'))
with (c/'postcheck.json').open('x') as out:json.dump(post,out,indent=2,allow_nan=False);out.write('\n')
print(json.dumps({k:post[k] for k in ['status','checks','head','old_tracked_files_preserved','old_cache_metadata_files_preserved','prior_control_marker_files_preserved','derived_rows','new_asset_bytes']}|{'phases':phases,'decision':result['decision'],'strongest_control':result['strongest_control'],'macro_quality_gain':result['macro_quality_gain'],'quality_gates':result['quality_gates'],'numerical_gates':result['numerical_gates'],'new_output_file_count':len(files),'result_sha256':sha(o/'evaluation/results.json'),'postcheck_sha256':sha(c/'postcheck.json')},allow_nan=False))
print('SAVED_MACRO',json.dumps(result['macro'],allow_nan=False));print('SAVED_GROUP_GAINS',json.dumps(result['group_quality_gains_over_strongest'],allow_nan=False))
