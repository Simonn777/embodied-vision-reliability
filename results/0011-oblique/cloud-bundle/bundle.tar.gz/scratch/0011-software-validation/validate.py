"""Frozen-source check and artificial-only test invocation. No dataset/model access."""
from pathlib import Path
import os,sys,subprocess,json,hashlib,time,platform
from datetime import datetime,timezone
b=Path('/workspace/scratch/a349d03a0e0a');r=b/'research-0011-oblique';c=b/'scratch/0011-software-validation'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
head='1951ae7bfd47f601c7187ee72ddd03ab905e7b56';src='a288f65bfb9d9e0d70dee72c0d83b020a0339458';fr='protocols/0011-oblique-development-freeze.json';expected='f45cfe56f99cdb8c4cb2ad6376a3c0813693666e2798941b9627d535c7a61e46'
assert git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain')
assert sha(r/fr)==expected and git('rev-parse',head+'^').decode().strip()==src
assert git('diff-tree','--no-commit-id','--name-only','-r',head).decode().strip()==fr
f=json.loads((r/fr).read_text());assert f['source_commit']==src and len(f['files'])==24
for p,h in f['files'].items():
 raw=(r/p).read_bytes();assert not (r/p).is_symlink() and sha(r/p)==h
 for ref in (src+':'+p,head+':'+p,':'+p):assert subprocess.check_output(['git','show',ref],cwd=r)==raw
assert not (b/'scratch/0011-oblique-v1').exists() and not (b/'scratch/0011-oblique-v1').is_symlink()
pre=dict(status='PASS_FROZEN_SOURCE_ONLY',head=head,source_commit=src,canonical_sha256=expected,files=f['files'],scientific_output_absent=True,python=sys.executable,python_version=sys.version,platform=platform.platform(),available_affinity=sorted(os.sched_getaffinity(0)),cgroup_memory_max=Path('/sys/fs/cgroup/memory.max').read_text().strip())
(c/'preflight.json').write_text(json.dumps(pre,indent=2)+'\n')
names=['marginal_coupling','oblique_view_geometry','oblique_fusion','prepare_oblique_development','run_oblique_predictions','evaluate_oblique_saved','supervise_oblique']
runner='''import unittest,json,sys,hashlib\nfrom pathlib import Path\nimport numpy as np\nnames=%r\nloader=unittest.TestLoader()\nsuites=[loader.discover('tests',pattern='test_'+n+'.py') for n in names]\ncounts={n:s.countTestCases() for n,s in zip(names,suites)}\nresult=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(suites))\nd=dict(tests_run=result.testsRun,skipped=len(result.skipped),failures=len(result.failures),errors=len(result.errors),per_file_test_counts=counts,numpy_version=np.__version__,numpy_file=np.__file__,numpy_module_sha256=hashlib.sha256(Path(np.__file__).read_bytes()).hexdigest(),torch_imported='torch' in sys.modules,scope='Artificial fixtures only; Linux micro-child executes; no scientific dataset/model calls.')\nPath(%r).write_text(json.dumps(d,indent=2)+'\\n')\nprint(json.dumps(d))\nraise SystemExit(0 if result.wasSuccessful() and not result.skipped and not d['torch_imported'] else 1)\n''' % (names,str(c/'test-results.json'))
(c/'run_artificial_suite.py').write_text(runner)
env=os.environ.copy();env['PYTHONPATH']=str(b/'bootstapir-cache/runtime-fixed')+':'+str(r/'src')+':'+str(r/'scripts')
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:env[k]='4'
env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONNOUSERSITE']='1'
cmd=['timeout','--kill-after=5s','120',sys.executable,'-W','error',str(c/'run_artificial_suite.py')]
command=dict(argv=cmd,cwd=str(r),PYTHONPATH=env['PYTHONPATH'],numeric_threads=4,affinity=[0,1,2,3],AS_bytes=8*1024**3,timeout_seconds=120,validation_source_sha256=sha(Path(__file__)),runner_sha256=sha(c/'run_artificial_suite.py'),head=head,freeze_sha256=expected)
(c/'command.json').write_text(json.dumps(command,indent=2)+'\n');start=datetime.now(timezone.utc).isoformat();t=time.monotonic();pid=os.fork()
if pid==0:
 os.chdir(r);os.sched_setaffinity(0,[0,1,2,3]);import resource;resource.setrlimit(resource.RLIMIT_AS,(8*1024**3,8*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 for fd,n in [(1,'stdout.log'),(2,'stderr.log')]:
  out=os.open(c/n,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.dup2(out,fd);os.close(out)
 os.execvpe(cmd[0],cmd,env)
_,status,usage=os.wait4(pid,0);exitcode=os.waitstatus_to_exitcode(status)
record=dict(actual_exit=exitcode,raw_wait_status=status,started_utc=start,ended_utc=datetime.now(timezone.utc).isoformat(),wall_seconds=time.monotonic()-t,user_cpu_seconds=usage.ru_utime,system_cpu_seconds=usage.ru_stime,max_rss_kib=usage.ru_maxrss,command_sha256=sha(c/'command.json'),logs={n:dict(bytes=(c/n).stat().st_size,sha256=sha(c/n)) for n in ['stdout.log','stderr.log']},parent_boundary='Test child wait4 observed here; this recording parent has only the external tool return, no additional wait4 observer.')
(c/'execution.json').write_text(json.dumps(record,indent=2)+'\n')
post=dict(frozen_files_unchanged=all(sha(r/p)==h for p,h in f['files'].items()),canonical_unchanged=sha(r/fr)==expected,git_clean=not bool(git('status','--porcelain')),scientific_output_absent=not (b/'scratch/0011-oblique-v1').exists())
(c/'postcheck.json').write_text(json.dumps(post,indent=2)+'\n');print(json.dumps(record));print((c/'test-results.json').read_text() if (c/'test-results.json').exists() else 'no result JSON');print(json.dumps(post))
if exitcode:print((c/'stderr.log').read_text()[-6000:])
assert all(post.values());sys.exit(exitcode)
