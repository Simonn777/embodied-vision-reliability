import unittest,json,sys,hashlib
from pathlib import Path
import numpy as np
names=['marginal_coupling', 'oblique_view_geometry', 'oblique_fusion', 'prepare_oblique_development', 'run_oblique_predictions', 'evaluate_oblique_saved', 'supervise_oblique']
loader=unittest.TestLoader()
suites=[loader.discover('tests',pattern='test_'+n+'.py') for n in names]
counts={n:s.countTestCases() for n,s in zip(names,suites)}
result=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(suites))
d=dict(tests_run=result.testsRun,skipped=len(result.skipped),failures=len(result.failures),errors=len(result.errors),per_file_test_counts=counts,numpy_version=np.__version__,numpy_file=np.__file__,numpy_module_sha256=hashlib.sha256(Path(np.__file__).read_bytes()).hexdigest(),torch_imported='torch' in sys.modules,scope='Artificial fixtures only; Linux micro-child executes; no scientific dataset/model calls.')
Path('/workspace/scratch/a349d03a0e0a/scratch/0011-software-validation/test-results.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d))
raise SystemExit(0 if result.wasSuccessful() and not result.skipped and not d['torch_imported'] else 1)
