"""External command receipt for four authorized saved-only checker invocations."""
from pathlib import Path
import os,sys,json,hashlib,time,platform
from datetime import datetime,timezone
b=Path('/workspace/scratch/a349d03a0e0a');c=Path(__file__).parent;r=b/'research-0011-oblique';o=b/'scratch/0011-oblique-v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def spec(p):return dict(bytes=p.stat().st_size,sha256=sha(p))
label=sys.argv[1]
commands={
 'metrics-selftest':[str(c/'review_0011_saved_metrics.py'),'--self-test','--output',str(c/'metrics-selftest.json')],
 'coupling-selftest':[str(c/'review_0011_saved_coupling.py'),'--self-test'],
 'metrics-review':[str(c/'review_0011_saved_metrics.py'),'--root',str(o),'--repo',str(r),'--output',str(c/'metrics-review.json')],
 'coupling-review':[str(c/'review_0011_saved_coupling.py'),'--root',str(o),'--output',str(c/'coupling-review.json')],
}
args=commands[label];cmd=['timeout','--kill-after=5s','1800',sys.executable,'-W','error',*args]
expected={'review_0011_saved_metrics.py':'aee7c5ad9ccefb5772d3c03891127b047b1010fe47de2856dad7cfa792e45af1','review_0011_saved_coupling.py':'cc46b586d0bc11f0f8006e51282eaf13fd6670da50fafef3cb25a88a1f77295f'}
for n,h in expected.items():assert sha(c/n)==h
binding=c/'original-binding.json'
if not binding.exists():
 p=b/'scratch/0011-pilot-control/postcheck.json';d=json.loads(p.read_text());f=json.loads((r/'protocols/0011-oblique-development-freeze.json').read_text())
 for n,v in d['new_output_inventory'].items():assert spec(o/n)==v
 for n,h in f['files'].items():assert sha(r/n)==h
 with binding.open('x') as w:json.dump(dict(postcheck=spec(p),original_output_files=d['new_output_inventory'],freeze=spec(r/'protocols/0011-oblique-development-freeze.json'),frozen_files=f['files']),w,indent=2);w.write('\n')
env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1','PYTHONPATH':str(b/'bootstapir-cache/runtime-fixed'),'CUDA_VISIBLE_DEVICES':''}
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS','NUMEXPR_NUM_THREADS']:env[k]='4'
record=dict(argv=cmd,cwd=str(r),environment=env,limits=dict(affinity=[0,1,2,3],address_space_bytes=8*1024**3,external_timeout_seconds=1800),checker_sha256=sha(Path(args[0])),capture_sha256=sha(Path(__file__)),input_binding_sha256=sha(binding),python_version=sys.version,platform=platform.platform())
with (c/(label+'.command.json')).open('x') as w:json.dump(record,w,indent=2);w.write('\n')
start=datetime.now(timezone.utc).isoformat();t=time.monotonic();pid=os.fork()
if pid==0:
 os.chdir(r);os.sched_setaffinity(0,[0,1,2,3]);import resource;resource.setrlimit(resource.RLIMIT_AS,(8*1024**3,8*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 for fd,suffix in [(1,'.stdout.log'),(2,'.stderr.log')]:
  q=os.open(c/(label+suffix),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);os.dup2(q,fd);os.close(q)
 os.execve('/usr/bin/timeout',cmd,env)
_,st,us=os.wait4(pid,0);exitcode=os.waitstatus_to_exitcode(st)
d=dict(label=label,actual_exit=exitcode,raw_wait_status=st,started_utc=start,ended_utc=datetime.now(timezone.utc).isoformat(),wall_seconds=time.monotonic()-t,user_cpu_seconds=us.ru_utime,system_cpu_seconds=us.ru_stime,max_rss_kib=us.ru_maxrss,command=spec(c/(label+'.command.json')),logs={n:spec(c/(label+n)) for n in ['.stdout.log','.stderr.log']},checker_sha256=sha(Path(args[0])),input_binding_sha256=sha(binding),parent_observer_boundary='Actual wait4 for timeout/checker child; recording parent itself has tool return only, no recursive observer.')
with (c/(label+'.execution.json')).open('x') as w:json.dump(d,w,indent=2);w.write('\n')
print(json.dumps(d));print((c/(label+'.stdout.log')).read_text()[:1500]);print((c/(label+'.stderr.log')).read_text()[-1600:]);sys.exit(exitcode)
