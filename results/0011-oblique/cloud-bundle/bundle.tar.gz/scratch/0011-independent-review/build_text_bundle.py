"""Package existing text evidence only; no scientific invocation, array decode or mutation."""
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile,gzip,io,subprocess,re
b=Path('/workspace/scratch/a349d03a0e0a');review=b/'scratch/0011-independent-review';root=b/'scratch/0011-oblique-v1';pilot=b/'scratch/0011-pilot-control';sw=b/'scratch/0011-software-validation';repo=b/'research-0011-oblique';out=b/'scratch/0011-review-text-bundle'
out.mkdir(exist_ok=False)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def spec(p):return dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n')
bind=json.loads((review/'original-binding.json').read_text());baseline=json.loads((pilot/'preexecution.json').read_text())
assert set(bind['original_output_files'])=={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()} and len(bind['original_output_files'])==174
for name,d in bind['original_output_files'].items():assert spec(root/name)==d
for name,h in bind['frozen_files'].items():assert sha((repo/name).read_bytes())==h
assert spec(repo/'protocols/0011-oblique-development-freeze.json')==bind['freeze']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
# Confirm preservation after reviewers, including their source pins.
for name,h in baseline['tracked'].items():assert sha((repo/name).read_bytes())==h
for name,d in baseline['previous_controls_and_markers'].items():assert spec(b/name)==d
for name,d in baseline['old_cache'].items():
 p=b/name;s=p.lstat();st=dict(bytes=s.st_size,dev=s.st_dev,inode=s.st_ino,nlink=s.st_nlink,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns);assert st=={k:v for k,v in d.items() if k!='sha256'}
 if 'sha256' in d:assert sha(p.read_bytes())==d['sha256']
sources=json.loads((review/'source-binding.json').read_text())
for name,h in sources['copied_scripts'].items():assert sha((review/name).read_bytes())==h
files={};manifest={};omitted={}
def add(p,category):
 raw=p.read_bytes();raw.decode('utf-8');name=str(p.relative_to(b));assert not p.is_symlink() and '..' not in PurePosixPath(name).parts and name not in files
 assert p.suffix!='.npz' and p.name!='active.lock'
 assert not re.search(rb'https://[^\s\"<>]+[?&](?:X-Amz-Signature|X-Goog-Signature|token|sig|Signature)=',raw)
 assert not re.search(rb'(?:sk-proj-|ghp_|github_pat_)[A-Za-z0-9]{16,}',raw)
 assert not re.search(rb'/(?:Users|home)/[^\s\"<>]+',raw)
 files[name]=raw;manifest[name]=dict(original_source=name,original=spec(p),public_bytes=len(raw),public_sha256=sha(raw),mode='byte-exact',category=category)
for p in sorted(root.rglob('*')):
 if p.is_file() and p.suffix in ['.json','.log']:add(p,'original-study-text')
for p in sorted(pilot.iterdir()):
 if not p.is_file() or not (p.suffix in ['.py','.json','.log'] or p.name.endswith('.tool-exit.txt')):continue
 if p.name=='preexecution.json':
  omitted[str(p.relative_to(b))]=spec(p)|{'reason':'Full historical tracked path/hash inventory3393 entries omitted from public copy; original bytes retained privately.'};continue
 add(p,'original-pilot-control')
for p in sorted(sw.iterdir()):
 if p.is_file() and p.suffix in ['.py','.json','.log']:add(p,'original-artificial-validation')
for p in sorted(review.iterdir()):
 if p.is_file() and p.suffix in ['.py','.json','.log']:add(p,'independent-review')
# Clearly labeled derivative replaces only the public view of the large old inventory.
summary={k:v for k,v in baseline.items() if k not in ['tracked','old_cache','previous_controls_and_markers']}
summary.update(derivation='Public summary only, NOT the byte-exact original preexecution.json.',original_source='scratch/0011-pilot-control/preexecution.json',original=spec(pilot/'preexecution.json'),omitted_sections={'tracked':len(baseline['tracked']),'old_cache':len(baseline['old_cache']),'previous_controls_and_markers':len(baseline['previous_controls_and_markers'])},preservation_after_reviews='All original recorded hashes/stat metadata rechecked and unchanged.')
raw=(json.dumps(summary,indent=2)+'\n').encode();name='summaries/preexecution-public-summary.json';files[name]=raw;manifest[name]=dict(original_source='scratch/0011-pilot-control/preexecution.json',original=spec(pilot/'preexecution.json'),public_bytes=len(raw),public_sha256=sha(raw),mode='explicit-summary-derivative',omitted_fields=list(summary['omitted_sections']))
# The historical terminal summaries were not redirected. Preserve their true observation boundary.
exceptions=dict(scope='Two read-only terminal summary errors after completed derive; no scientific failure or rerun.',original_record='scratch/0011-pilot-control/readonly-summary-errors.json',errors=[dict(tool_chunk='852296',actual_exit=1,exception='FileNotFoundError',reason='Attempted derived/receipt.json; frozen derivation actually writes seal.json.',original_command='Read derived directory, then json.loads((p/receipt.json).read_text()); no scientific function invoked.',log_boundary='Original traceback appears in actual tool record; no separate closed stderr/stdout file was created.'),dict(tool_chunk='9109cd',actual_exit=1,reason='Used dict inspection on diagnostics list; oversized terminal output was truncated by tool transport.',original_command='Static rg; JSON-only loop printing list(d), then d.items() for seal.json/predictions.json/diagnostics.json.',log_boundary='Complete untruncated terminal stdout/stderr was not archived. Do not label reconstruction or current saved diagnostics as the original command log.')],corrected_check=dict(tool_chunk='3f9d98',actual_exit=0,verified='seal.status=sealed, model_calls0, GT_openedfalse; hash-check sealed files before single score.'),no_original_files_changed=True)
raw=(json.dumps(exceptions,indent=2)+'\n').encode();name='summaries/readonly-summary-error-provenance.json';files[name]=raw;manifest[name]=dict(original_source='Actual observed tool records852296/9109cd and original error metadata',original=None,public_bytes=len(raw),public_sha256=sha(raw),mode='new-provenance-note-not-original-log')
metric=json.loads((review/'metrics-review.json').read_text());couple=json.loads((review/'coupling-review.json').read_text())
records={label:json.loads((review/(label+'.execution.json')).read_text()) for label in ['metrics-selftest','coupling-selftest','metrics-review','coupling-review']}
for label,e in records.items():
 assert e['actual_exit']==e['raw_wait_status']==0
 assert spec(review/(label+'.command.json'))==e['command']
 for suffix,d in e['logs'].items():assert spec(review/(label+suffix))==d
write(out/'README.json',dict(status='SAVED_INDEPENDENT_REVIEW_PASS_SCIENCE_NO_GO',AI_assisted=True,metrics=dict(status=metric['status'],checks=metric['checks'],numeric_checks=metric['numeric_checks'],max_absolute_difference=metric['max_absolute_difference']),coupling=dict(status=couple['status'],processed_points=couple['processed_points'],compared_coordinates=couple['compared_coordinates'],max_absolute_difference_by_method=couple['max_absolute_difference_by_method']),executions={k:{q:v[q] for q in ['actual_exit','raw_wait_status','wall_seconds','max_rss_kib']} for k,v in records.items()},scientific_decision='NO_GO',limitations=['Review PASS verifies saved arithmetic/bindings, not method efficacy or novelty.','No model/forward, preparation,derive,formal score,training or download repeated.','Raw RGB/GT NPZ, logits NPZ, weights and cache binary payloads excluded; only JSON/log/source records included.','Original read-only terminal summary errors preserved with honest truncated/missing closed-log boundary.','Full historical preexecution map remains private; a labeled derivative carries original hash/size.'],new_asset_bytes=0,published=False,git_transport=dict(owner_publication_authorized=True,last_fetch_exit=0,origin_host='github.com',credential_helper_configured=False,push_tested=False,actual_write_availability='UNKNOWN; fetch demonstrates read access, no test push or credential access performed.'),original_preservation=dict(output_files=174,frozen_files=24,old_tracked_files=len(baseline['tracked']),old_cache_metadata_files=len(baseline['old_cache']),prior_controls_and_markers=len(baseline['previous_controls_and_markers'])),wrapper_self_exclusion='README.json, manifest.json, bundle.tar.gz and bundle-metadata.json excluded from payload manifest to avoid circular hashes; their hashes listed externally.'))
write(out/'manifest.json',dict(schema='0011-saved-text-bundle-manifest-v1',files=manifest,omitted=omitted,file_count=len(files),total_payload_bytes=sum(len(x) for x in files.values()),self_exclusion='Manifest/README/archive/metadata wrappers excluded; no recursive self hash.'))
for name,raw in files.items():
 p=out/'payload'/name;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(raw)
stream=io.BytesIO()
with tarfile.open(fileobj=stream,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for name,raw in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(raw);info.mtime=0;info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';tar.addfile(info,io.BytesIO(raw))
compressed=gzip.compress(stream.getvalue(),mtime=0)
with (out/'bundle.tar.gz').open('xb') as f:f.write(compressed)
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(files)
 for m in members:assert m.isfile() and tar.extractfile(m).read()==files[m.name]
for p in root.rglob('*'):
 if p.is_file():assert spec(p)==bind['original_output_files'][str(p.relative_to(root))]
meta=dict(schema='0011-saved-text-bundle-v1',status='READY_FOR_PARENT_REVIEW_NOT_PUSHED',file_count=len(files),total_payload_bytes=sum(map(len,files.values())),archive=spec(out/'bundle.tar.gz'),manifest=spec(out/'manifest.json'),README=spec(out/'README.json'),roundtrip_verified=True,original_outputs_unchanged=174,frozen_sources_unchanged=24,review_commit=sources['published_commit'],exceptions='Two historical read-only terminal failures are documented; complete second terminal output was not archived, so not falsely reproduced.',new_asset_bytes=0)
write(out/'bundle-metadata.json',meta);print(json.dumps(meta))
